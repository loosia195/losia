import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Dọn dữ liệu cũ (dev)
  await prisma.cartItem.deleteMany();
  await prisma.cart.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.productImage.deleteMany();
  await prisma.inventory.deleteMany();
  await prisma.product.deleteMany();
  await prisma.brand.deleteMany();
  await prisma.category.deleteMany();

  // Optional: tạo brand & category mẫu
  const brandEF = await prisma.brand.create({ data: { name: 'Eileen Fisher', slug: 'eileen-fisher' } });
  const brandZara = await prisma.brand.create({ data: { name: 'Zara', slug: 'zara' } });
  const catWomen = await prisma.category.create({ data: { name: 'Women', slug: 'women' } });
  const catKids = await prisma.category.create({ data: { name: 'Kids', slug: 'kids' } });

  const items = [
    {
      sku: 'SKU-0001',
      title: 'Eileen Fisher Linen Dress',
      description: 'Pre‑loved linen dress, breathable & elegant.',
      price: 95000,
      oldPrice: 145000,
      condition: 'Very good',
      brandId: brandEF.id,
      categoryId: catWomen.id,
      images: [
        { url: '/assets/images/main/product1.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/01-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    },
    {
      sku: 'SKU-0002',
      title: 'Zara Kids Denim Jacket',
      description: 'Cute denim jacket for kids, size 110.',
      price: 120000,
      oldPrice: 180000,
      condition: 'Good',
      brandId: brandZara.id,
      categoryId: catKids.id,
      images: [
        { url: '/assets/images/main/product2.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/02-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    },
    {
      sku: 'SKU-0003',
      title: 'Uniqlo Women Blouse',
      description: 'Soft cotton blouse, everyday essential.',
      price: 80000,
      oldPrice: 130000,
      condition: 'Excellent',
      brandId: null,
      categoryId: catWomen.id,
      images: [
        { url: '/assets/images/main/product3.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/03-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    },
    {
      sku: 'SKU-0004',
      title: 'H&M Girl Skirt',
      description: 'Skater skirt, comfy & playful.',
      price: 65000,
      oldPrice: 99000,
      condition: 'Very good',
      brandId: null,
      categoryId: catKids.id,
      images: [
        { url: '/assets/images/main/product4.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/04-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    },
    {
      sku: 'SKU-0005',
      title: 'Mango Wrap Dress',
      description: 'Wrap dress with flattering fit.',
      price: 135000,
      oldPrice: 220000,
      condition: 'Good',
      brandId: null,
      categoryId: catWomen.id,
      images: [
        { url: '/assets/images/main/product5.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/05-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    },
    {
      sku: 'SKU-0006',
      title: 'Gap Kids Tee Pack',
      description: '2x cotton tees, soft & durable.',
      price: 50000,
      oldPrice: 90000,
      condition: 'Good',
      brandId: null,
      categoryId: catKids.id,
      images: [
        { url: '/assets/images/main/product6.jpg', width: 1080, height: 1440, order: 1 },
        { url: '/assets/images/thumb/06-thumb.jpg', width: 270, height: 360, order: 2 }
      ],
    }
  ];

  for (const it of items) {
    const created = await prisma.product.create({
      data: {
        sku: it.sku,
        title: it.title,
        description: it.description,
        condition: it.condition,
        price: it.price,
        oldPrice: it.oldPrice,
        brandId: it.brandId || undefined,
        categoryId: it.categoryId || undefined,
        images: {
          create: it.images
        },
        status: 'ACTIVE'
      },
      include: { images: true }
    });
    await prisma.inventory.create({ data: { productId: created.id, quantity: 1 } });
  }

  console.log('Seeded products successfully.');
}

main()
  .then(async () => { await prisma.$disconnect(); })
  .catch(async (e) => { console.error(e); await prisma.$disconnect(); process.exit(1); });