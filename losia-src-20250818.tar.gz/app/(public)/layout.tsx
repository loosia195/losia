// app/(public)/layout.tsx
import "@/styles/globals.css";
import React from "react";
import Script from "next/script";
import Link from "next/link";
import PageView from "@/components/analytics/PageView";
import { Inter } from "next/font/google";
import type { Metadata } from "next";

// Domain chuẩn cho canonical / JSON-LD
const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "https://losia.vn").replace(/\/$/, "");

// SEO cơ bản + metadataBase để Next tạo canonical tuyệt đối
export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "LOSIA",
  description: "Secondhand First",
};

// Viewport cho mobile
export const viewport = { width: "device-width", initialScale: 1, maximumScale: 1 };

// Font tối ưu (swap để tránh nháy chữ)
const inter = Inter({ subsets: ["latin"], display: "swap" });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const GA_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID;
  const enableAnalytics = process.env.NEXT_PUBLIC_ENABLE_ANALYTICS === "1" && !!GA_ID;

  const cdn = process.env.NEXT_PUBLIC_IMG_CDN ?? "https://cdn.losia.vn";

  return (
    <html lang="vi">
      <head>
        {/* Tối ưu tải ảnh */}
        <link rel="preconnect" href={cdn} crossOrigin="" />
        <link rel="dns-prefetch" href={cdn} />

        {/* Font */}
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />

        {/* GA4 */}
        {enableAnalytics ? <link rel="preconnect" href="https://www.googletagmanager.com" /> : null}
      </head>

      <body className={inter.className}>
        <header className="border-b">
          <div className="mx-auto max-w-6xl p-4 flex items-center justify-between">
            <Link href="/" className="font-semibold">LOSIA</Link>
            <nav className="flex gap-4 text-sm">
              <Link href="/about">About</Link>
              <Link href="/cart">Cart</Link>
            </nav>
          </div>
        </header>

        {/* Để page tự quản lý container/padding, tránh double max-w-6xl */}
        <main>{children}</main>

        <footer className="border-t mt-8">
          <div className="mx-auto max-w-6xl p-4 text-sm text-gray-500">
            © {new Date().getFullYear()} LOSIA — Secondhand First
          </div>
        </footer>

        {/* GA4 – bật theo env */}
        {enableAnalytics ? (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
              strategy="afterInteractive"
            />
            <Script id="ga4-init" strategy="afterInteractive">
              {`
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                // Tự gửi page_view bằng PageView component; tắt auto gửi từ GA
                gtag('config', '${GA_ID}', { send_page_view: false });
              `}
            </Script>
            <PageView />
          </>
        ) : null}

        {/* ✅ JSON-LD: Organization */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "LOSIA",
              url: SITE_URL,
              logo: `${SITE_URL}/assets/logo.png`, // đổi nếu logo ở path khác
              sameAs: [
                // cập nhật nếu có social
                "https://www.facebook.com/losia",
                "https://www.instagram.com/losia",
              ].filter(Boolean),
            }),
          }}
        />
        {/* ✅ JSON-LD: WebSite + SearchAction */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              url: SITE_URL,
              potentialAction: {
                "@type": "SearchAction",
                target: `${SITE_URL}/search?q={search_term_string}`,
                "query-input": "required name=search_term_string",
              },
            }),
          }}
        />
      </body>
    </html>
  );
}
