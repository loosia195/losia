import Link from 'next/link';
import { cookies } from 'next/headers';
import prisma from '@/lib/prisma';

export default async function CartPage() {
  const cartRaw = cookies().get('losia_cart_v1')?.value || '[]';
  const cart: { productId: number; qty: number }[] = JSON.parse(cartRaw || '[]');
  const ids = cart.map(c => c.productId);
  const products = ids.length ? await prisma.product.findMany({ where: { id: { in: ids } } }) : [];

  const lines = products.map(p => {
    const qty = cart.find(c => c.productId === p.id)?.qty || 1;
    const line = p.price * qty;
    const oldLine = (p.oldPrice || p.price) * qty;
    return { p, qty, line, oldLine };
  });
  const subtotal = lines.reduce((s, l) => s + l.oldLine, 0);
  const total = lines.reduce((s, l) => s + l.line, 0);
  const discount = Math.max(0, subtotal - total);

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 grid grid-cols-1 md:grid-cols-3 gap-6">
      <section className="md:col-span-2">
        <h1 className="text-xl font-semibold mb-4">Your Cart</h1>
        {!lines.length && (
          <div className="text-gray-600">Giỏ hàng trống. <Link href="/" className="underline">Tiếp tục mua sắm</Link></div>
        )}
        <ul className="divide-y rounded-xl border">
          {lines.map(({ p, qty }) => (
            <li key={p.id} className="p-4 flex items-center gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.images?.[0] || '/assets/images/main/product1.jpg'} alt={p.name} className="h-20 w-16 rounded-md object-cover" />
              <div className="flex-1">
                <div className="text-sm font-medium line-clamp-1">{p.name}</div>
                <div className="text-xs text-gray-500">Qty: {qty}</div>
              </div>
              <div className="text-sm font-semibold">{formatVND(p.price * qty)}</div>
              <form action={`/api/cart/${p.id}`} method="POST" className="ml-2">
                <input type="hidden" name="_method" value="DELETE" />
                {/* Nút xoá dùng fetch client thường tốt hơn; để tối giản giữ form */}
              </form>
            </li>
          ))}
        </ul>
      </section>

      <aside className="md:col-span-1">
        <div className="rounded-xl border p-4 sticky top-6">
          <h2 className="font-semibold mb-3">Order Summary</h2>
          <div className="flex justify-between text-sm py-1"><span>Subtotal</span><span>{formatVND(subtotal)}</span></div>
          <div className="flex justify-between text-sm py-1"><span>Discount</span><span>-{formatVND(discount)}</span></div>
          <div className="flex justify-between text-base font-semibold py-2 border-t mt-2"><span>Total</span><span>{formatVND(total)}</span></div>
          <Link href="/checkout" className="mt-3 block text-center rounded-lg bg-black text-white px-4 py-2">Checkout</Link>
          <Link href="/" className="mt-2 block text-center underline text-sm">Continue shopping</Link>
        </div>
      </aside>
    </main>
  );
}

function formatVND(n: number) {
  try { return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(n); } catch { return `${n}₫`; }
}
