// app/(public)/about/page.tsx
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About | LOSIA",
  alternates: { canonical: "/about" }, // -> https://losia.vn/about
};

export default function AboutPage() {
  return <main className="mx-auto max-w-6xl p-4">About LOSIA</main>;
}
