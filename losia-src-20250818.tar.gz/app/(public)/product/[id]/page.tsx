// app/(public)/product/[id]/page.tsx

// ❌ Bỏ import Image – đã thay bằng SmartImage trong ProductImageSection/MainImage
// import Image from 'next/image';
import ProductAnalytics from '@/components/analytics/ProductAnalytics';
import type { Metadata } from 'next';
import AddToCartTracked from '@/components/product/AddToCartTracked';
import { formatVND } from '@/lib/format';

// Trust blocks
import EstimatedPricing from '@/components/product/ProductDetailSection/EstimatedPricing';
import SafeSecureGuarantee from '@/components/product/ProductDetailSection/SafeSecureGuarantee';

// ✅ Gallery component (đã tạo ở bước trước)
// Nếu anh đặt file theo hướng dẫn trước: src/app/(public)/components/product/ProductImageGallery/...
// thì import như sau:
import ProductImageSection from '@/components/product/ProductImageGallery/ProductImageSection';

async function fetchProduct(id: string) {
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const isProd = process.env.NODE_ENV === 'production';
  const res = await fetch(`${base}/api/products/${id}`, isProd ? { next: { revalidate: 300 } } : { cache: 'no-store' });
  if (!res.ok) return null;
  return res.json();
}

/** -----------------------------------------
 *  (NEW) SEO: generateMetadata cho PDP
 *  ----------------------------------------- */
type PageProps = { params: { id: string } };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const p = await fetchProduct(params.id);
  if (!p) return { title: 'Sản phẩm không tồn tại | LOSIA' };

  const baseUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://losia.vn').replace(/\/$/, '');
  const url = `${baseUrl}/product/${p.id}`;
  const title = `${p.title} | ${p.brand ?? 'LOSIA'}`;
  const desc = [p.title, p.condition ? `Tình trạng: ${p.condition}` : null, p.price ? `Giá: ${formatVND(p.price)}` : null]
    .filter(Boolean)
    .join(' • ');

  // OpenGraph image: ưu tiên p.images[0] nếu có; nếu sau này chỉ có photoId thì sẽ bổ sung ghép URL CDN.
  const firstImage: string =
    (Array.isArray(p.images) && p.images.length > 0 && p.images[0]) ||
    '/assets/images/main/product1.jpg';

  return {
    title,
    description: desc,
    alternates: { canonical: url },
    openGraph: { title, description: desc, url, siteName: 'LOSIA', type: 'website', images: [{ url: firstImage }] },
    twitter: { card: 'summary_large_image', title, description: desc, images: [firstImage] },
  };
}

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = await fetchProduct(params.id);
  if (!product) return <div className="mx-auto max-w-4xl px-4 py-10">Sản phẩm không tồn tại.</div>;

  const outOfStock = (product.inventory ?? 0) <= 0;

  /** -----------------------------------------
   *  Chuẩn hóa mảng ảnh cho gallery
   *  ----------------------------------------- */
  type PhotoSource = { photoId?: string; src?: string; alt?: string };

  let imagesNormalized: PhotoSource[] = [];
  // Trường hợp 1: backend trả mảng URL ảnh sẵn (string[])
  if (Array.isArray(product.images) && product.images.length) {
    imagesNormalized = product.images.map((url: string) => ({ src: url, alt: product.title }));
  }
  // Trường hợp 2 (tương lai): backend trả mảng photos có photoId
  else if (Array.isArray(product.photos) && product.photos.length) {
    imagesNormalized = product.photos.map((ph: any) => ({ photoId: ph.photoId, alt: product.title }));
  }
  // Fallback
  else {
    imagesNormalized = [{ src: '/assets/images/main/product1.jpg', alt: product.title }];
  }

  /** -----------------------------------------
   *  (NEW) JSON-LD: Product + Breadcrumb
   *  ----------------------------------------- */
  const baseUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://losia.vn').replace(/\/$/, '');
  const productLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    image: Array.isArray(product.images) ? product.images : imagesNormalized.map(i => i.src).filter(Boolean),
    description: product.description?.slice(0, 300),
    brand: product.brand || 'LOSIA',
    sku: product.sku || product.id,
    offers: {
      '@type': 'Offer',
      priceCurrency: 'VND',
      price: product.price,
      availability: (product.inventory ?? 0) > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
      url: `${baseUrl}/product/${product.id}`,
    },
  };

  const breadcrumbLd = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: `${baseUrl}/` },
      {
        '@type': 'ListItem',
        position: 2,
        name: product.category || 'Women',
        item: `${baseUrl}/c/${product.categorySlug || 'women'}`,
      },
      { '@type': 'ListItem', position: 3, name: product.title, item: `${baseUrl}/product/${product.id}` },
    ],
  };

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 grid grid-cols-1 gap-6 md:grid-cols-2">
      {/* GA4 view_item */}
      <ProductAnalytics id={product.id} title={product.title} price={product.price} brand={product.brand} category={product.category} />

      {/* JSON-LD scripts */}
      <script type="application/ld+json" // @ts-ignore
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productLd) }} />
      <script type="application/ld+json" // @ts-ignore
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbLd) }} />

      {/* Cột trái: MAIN + THUMBNAILS gallery */}
      <div>
        <ProductImageSection
          images={imagesNormalized}
          productName={product.title}
          className="" // có thể thêm margin tùy ý
        />
      </div>

      {/* Cột phải: thông tin sản phẩm */}
      <div>
        <h1 className="text-xl font-semibold">{product.title}</h1>

        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-lg font-bold">{formatVND(product.price)}</span>
          {product.oldPrice && <span className="text-sm text-gray-400 line-through">{formatVND(product.oldPrice)}</span>}
          {outOfStock && <span className="ml-2 text-sm font-medium text-rose-600">Đã bán</span>}
        </div>

        {/* Estimated Pricing */}
        <EstimatedPricing oldPrice={product.oldPrice} price={product.price} />

        <p className="mt-3 text-sm text-gray-700">{product.description}</p>

        <div className="mt-4 text-sm">
          <div>
            <span className="text-gray-500">Condition:</span>{' '}
            <span className="font-medium">{product.condition || 'Good'}</span>
          </div>
          {typeof product.inventory === 'number' && (
            <div className="mt-1 text-gray-600">In stock: {product.inventory}</div>
          )}
        </div>

        <div className="mt-6">
          <AddToCartTracked
            product={{
              id: product.id,
              title: product.title,
              price: product.price,
              brand: product.brand,
              category: product.category,
            }}
            disabled={outOfStock}
          />
        </div>

        {/* Safe & Secure Shopping Guarantee */}
        <SafeSecureGuarantee />
      </div>
    </main>
  );
}
