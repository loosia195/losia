// src/app/api/cart/route.ts
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

type CartItem = { productId: string; qty: number };
const CART_COOKIE = 'losia_cart_v1';

function readCart(): CartItem[] {
  const store = cookies().get(CART_COOKIE)?.value || '[]';
  try { return JSON.parse(store); } catch { return []; }
}
function writeCart(items: CartItem[]) {
  cookies().set({
    name: CART_COOKIE,
    value: JSON.stringify(items),
    httpOnly: true,
    path: '/',
    sameSite: 'lax',
  });
}

export async function GET() {
  return NextResponse.json({ items: readCart() });
}

export async function POST(req: Request) {
  let productId = '';
  let qty = 1;

  // 1) Ưu tiên JSON
  try {
    if (req.headers.get('content-type')?.includes('application/json')) {
      const body = await req.json();
      productId = String(body?.productId || '');
      qty = Math.max(1, Number(body?.qty || 1));
    }
  } catch {}

  // 2) Nếu chưa có, thử FormData
  if (!productId) {
    try {
      const form = await req.formData();
      productId = String(form.get('productId') || '');
      qty = Math.max(1, Number(form.get('qty') || 1));
    } catch {}
  }

  // 3) Nếu vẫn chưa có, lấy từ query (?productId=…)
  if (!productId) {
    const url = new URL(req.url);
    productId = String(url.searchParams.get('productId') || '');
    qty = Math.max(1, Number(url.searchParams.get('qty') || 1));
  }

  if (!productId) {
    return NextResponse.json({ error: 'Invalid productId' }, { status: 400 });
  }

  const items = readCart();
  const idx = items.findIndex(i => i.productId === productId);
  if (idx >= 0) items[idx].qty += qty;
  else items.push({ productId, qty });

  writeCart(items);
  return NextResponse.json({ ok: true, items });
}
