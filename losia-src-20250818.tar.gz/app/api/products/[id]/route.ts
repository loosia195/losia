import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

interface Ctx { params: { id: string } }

export async function GET(_req: Request, { params }: Ctx) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      images: { orderBy: { order: 'asc' }, select: { url: true } },
      inventory: true,
      brand: true,
      category: true,
    },
  });
  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const urls = product.images.map((i) => i.url);

  return NextResponse.json({
    id: product.id,
    title: product.title,
    description: product.description,
    price: product.price,
    oldPrice: product.oldPrice,
    condition: product.condition,
    images: urls,
    inventory: product.inventory?.quantity ?? 0,
    brand: product.brand?.name ?? null,
    category: product.category?.name ?? null,
  });
}
