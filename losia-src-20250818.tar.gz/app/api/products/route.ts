import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const page = Number(searchParams.get('page') || '1');
  const limit = Number(searchParams.get('limit') || '24');
  const skip = (page - 1) * limit;

  const [rows, total] = await Promise.all([
    prisma.product.findMany({
      skip,
      take: limit,
      where: { status: 'ACTIVE' },
      orderBy: { createdAt: 'desc' },
      include: {
        images: {
          orderBy: { order: 'asc' },
          select: { url: true },
        },
      },
    }),
    prisma.product.count({ where: { status: 'ACTIVE' } }),
  ]);

  const items = rows.map((p) => {
    const urls = p.images.map((i) => i.url);
    const cover = urls[0] || '/assets/images/main/product1.jpg';
    return {
      id: p.id,
      sku: p.sku,
      title: p.title,
      description: p.description,
      price: p.price,
      oldPrice: p.oldPrice,
      condition: p.condition,
      cover,        // <— dùng cho Home card
      images: urls, // <— mảng URL ảnh
    };
  });

  return NextResponse.json({ items, total, page, limit });
}
