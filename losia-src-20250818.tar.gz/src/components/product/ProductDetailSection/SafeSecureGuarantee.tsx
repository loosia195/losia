export default function SafeSecureGuarantee() {
  return (
    <div className="mt-6 rounded-2xl border p-4 bg-white">
      <h3 className="text-sm font-semibold">Safe & Secure Shopping Guarantee</h3>
      <ul className="mt-2 text-sm space-y-1 list-disc pl-5">
        <li>Kiểm định tình trạng 2 bước trước khi giao</li>
        <li>Đổi trả trong 48h nếu sai mô tả</li>
        <li>Thanh toán an toàn: VNPAY, COD</li>
        <li>Bảo vệ thông tin người mua & người bán</li>
      </ul>
    </div>
  );
}
