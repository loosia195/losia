'use client';

import AddToCartButton from '@/components/product/AddToCartButton';

export default function AddToCartTracked({
  product,
  disabled,
}: {
  product: { id: string; title: string; price: number; brand?: string; category?: string };
  disabled?: boolean;
}) {
  return (
    <AddToCartButton
      productId={product.id}
      disabled={disabled}
      onAdded={() => {
        // GA4: add_to_cart
        (window as any).gtag?.('event', 'add_to_cart', {
          currency: 'VND',
          value: product.price,
          items: [
            {
              item_id: product.id,
              item_name: product.title,
              item_brand: product.brand,
              item_category: product.category,
              price: product.price,
              quantity: 1,
            },
          ],
          debug_mode: process.env.NEXT_PUBLIC_ENV !== 'production',
        });
      }}
    />
  );
}
