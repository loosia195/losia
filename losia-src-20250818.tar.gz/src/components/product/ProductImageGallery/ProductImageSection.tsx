// src/app/(public)/components/product/ProductImageGallery/ProductImageSection.tsx
'use client';

import React, { useState, useMemo, useCallback, useRef } from 'react';
import MainImage from './MainImage';
import SmartImage from '@/components/media/SmartImage';
import ArrowLeft from '@/icons/arrow-left.svg';
import ArrowRight from '@/icons/arrow-right.svg';
import ProductLightbox from './ProductLightbox'; // ✅ thêm

type PhotoSource = {
  photoId?: string;
  src?: string;
  alt?: string;
  blur?: string; // optional
};

type ProductImageSectionProps = {
  images: PhotoSource[];
  productName: string;
  initialIndex?: number;
  className?: string;
};

export default function ProductImageSection({
  images,
  productName,
  initialIndex = 0,
  className,
}: ProductImageSectionProps) {
  const safeImages = useMemo(() => (Array.isArray(images) ? images : []), [images]);
  const count = safeImages.length;

  const [index, setIndex] = useState(Math.min(initialIndex, Math.max(0, count ? count - 1 : 0)));
  const [open, setOpen] = useState(false); // ✅ state lightbox

  const current = safeImages[index];

  // Carousel wrap-around
  const prev = useCallback(() => count && setIndex((i) => (i - 1 + count) % count), [count]);
  const next = useCallback(() => count && setIndex((i) => (i + 1) % count), [count]);

  // Keyboard
  const onKey = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      if (!count) return;
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    },
    [count, next, prev]
  );

  // Swipe (mobile)
  const touchStartX = useRef<number | null>(null);
  const onTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    touchStartX.current = e.touches[0]?.clientX ?? null;
  };
  const onTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (touchStartX.current == null) return;
    const delta = e.changedTouches[0]?.clientX - touchStartX.current;
    if (typeof delta === 'number' && Math.abs(delta) > 40) (delta < 0 ? next : prev)();
    touchStartX.current = null;
  };

  if (!count) {
    return (
      <div className={className}>
        <MainImage src="/assets/images/main/product1.jpg" alt={productName} />
      </div>
    );
  }

  return (
    <section className={className} aria-label="Product media gallery">
      <div className="grid gap-4 md:grid-cols-12" tabIndex={0} onKeyDown={onKey}>
        {/* MAIN */}
        <div className="md:col-span-9">
          <div
            className="relative group select-none touch-pan-y"
            onTouchStart={onTouchStart}
            onTouchEnd={onTouchEnd}
          >
            {/* ✅ click vào ảnh để mở Lightbox */}
            <button
              type="button"
              className="block w-full text-left"
              onClick={() => setOpen(true)}
              aria-label="Phóng to ảnh"
            >
              <MainImage
                photoId={current.photoId}
                src={current.src}
                alt={current.alt || productName}
                priority
                className="overflow-hidden rounded-xl bg-gray-100"
                blur={current.blur}            // ✅ thêm dòng này

              />
            </button>

            {/* ✅ 2 nút TRÒN, chỉ icon, đáy giữa; mobile luôn hiện, desktop hover mới hiện; ẩn nếu chỉ có 1 ảnh */}
            {count > 1 && (
              <div className="absolute inset-x-0 bottom-2 z-20 flex justify-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation(); // tránh mở lightbox khi bấm nút
                    prev();
                  }}
                  aria-label="Ảnh trước"
                  className={[
                    'inline-flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-lg',
                    'ring-1 ring-black/10',
                    'opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity',
                    'focus:outline-none focus-visible:ring-2 focus-visible:ring-black/30',
                  ].join(' ')}
                >
                  <ArrowLeft className="h-5 w-5" aria-hidden />
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    next();
                  }}
                  aria-label="Ảnh tiếp theo"
                  className={[
                    'inline-flex h-11 w-11 items-center justify-center rounded-full bg-white shadow-lg',
                    'ring-1 ring-black/10',
                    'opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity',
                    'focus:outline-none focus-visible:ring-2 focus-visible:ring-black/30',
                  ].join(' ')}
                >
                  <ArrowRight className="h-5 w-5" aria-hidden />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* THUMBNAILS */}
        <div className="md:col-span-3">
          <div className="grid grid-cols-5 gap-2 md:grid-cols-1">
            {safeImages.map((img, i) => {
              const selected = i === index;
              return (
                <button
                  key={i}
                  type="button"
                  aria-label={`Ảnh ${i + 1}`}
                  aria-current={selected}
                  onClick={() => setIndex(i)}
                  className={[
                    'relative aspect-[3/4] overflow-hidden rounded-lg',
                    'ring-1 ring-gray-200 hover:ring-gray-300 focus:outline-none focus:ring-2 focus:ring-black',
                    selected ? 'ring-2 ring-emerald-500' : '',
                  ].join(' ')}
                >
                  <SmartImage
                    kind="product"
                    photoId={img.photoId}
                    src={img.src}
                    preset="pdpThumb"
                    alt={img.alt || productName}
                    aspectRatio="3/4"
                    className="h-full w-full"
                    imgClassName="object-cover"
                    placeholder={img.blur ? 'blur' : 'empty'}   // ✅ bật blur
                    blurDataURL={img.blur}                       // ✅ truyền blur
                  />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ✅ Lightbox */}
      <ProductLightbox
        open={open}
        onClose={() => setOpen(false)}
        image={{ photoId: current.photoId, src: current.src, alt: current.alt || productName }}
        onPrev={() => setIndex((i) => (i - 1 + count) % count)}
        onNext={() => setIndex((i) => (i + 1) % count)}
      />
    </section>
  );
}
