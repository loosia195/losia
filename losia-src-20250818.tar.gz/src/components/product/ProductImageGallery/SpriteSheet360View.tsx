'use client';

import React, { useRef, useState } from 'react';

type Props = {
  spriteSrc: string; // đường dẫn sprite (public/CDN)
  frames: number;    // tổng số khung
  className?: string;
};

export default function SpriteSheet360View({ spriteSrc, frames, className }: Props) {
  const [frame, setFrame] = useState(0);
  const dragging = useRef(false);
  const lastX = useRef<number | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    dragging.current = true;
    lastX.current = e.clientX;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerUp = (e: React.PointerEvent) => {
    dragging.current = false;
    lastX.current = null;
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging.current || lastX.current == null) return;
    const delta = e.clientX - lastX.current;
    if (Math.abs(delta) >= 4) {
      const step = delta > 0 ? -1 : 1; // kéo phải → lùi khung
      setFrame((f) => (f + step + frames) % frames);
      lastX.current = e.clientX;
    }
  };

  const perc = (100 / (frames - 1)) * frame; // vị trí background theo frame

  return (
    <div
      className={className ?? 'h-[360px] w-full overflow-hidden rounded-xl bg-gray-100 ring-1 ring-black/5'}
      style={{
        backgroundImage: `url(${spriteSrc})`,
        backgroundRepeat: 'no-repeat',
        backgroundSize: `${frames * 100}% 100%`,
        backgroundPosition: `${perc}% 0`,
        touchAction: 'pan-y',
        cursor: 'grab',
      }}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onPointerMove={onPointerMove}
      aria-label="Xoay 360 độ"
      role="img"
    />
  );
}
