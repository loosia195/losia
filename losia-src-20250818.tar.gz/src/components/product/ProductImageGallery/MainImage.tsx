// src/app/(public)/components/product/ProductImageGallery/MainImage.tsx
'use client';

import React, { useRef, useState } from 'react';
import SmartImage from '@/components/media/SmartImage';

type MainImageProps = {
  photoId?: string;
  src?: string;
  alt: string;
  priority?: boolean;
  className?: string;    // wrapper
  hoverZoom?: boolean;   // đã có từ trước
  zoomScale?: number;    // đã có từ trước
  blur?: string;         // ✅ NEW: base64 blur
};

export default function MainImage({
  photoId,
  src,
  alt,
  priority = true,
  className,
  hoverZoom = true,
  zoomScale = 2,
  blur,
}: MainImageProps) {
  const frameRef = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState(false);
  const [origin, setOrigin] = useState<{ x: number; y: number }>({ x: 50, y: 50 });

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!hoverZoom || !frameRef.current) return;
    const rect = frameRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    const clamp = (v: number) => Math.max(0, Math.min(100, v));
    setOrigin({ x: clamp(x), y: clamp(y) });
  };

  const imgStyle: React.CSSProperties | undefined = hoverZoom
    ? {
        transformOrigin: `${origin.x}% ${origin.y}%`,
        transform: `scale(${hover ? zoomScale : 1})`,
        transition: hover ? 'transform 0s' : 'transform 150ms ease-out',
      }
    : undefined;

  return (
    <div
      ref={frameRef}
      className={className ?? 'overflow-hidden rounded-xl bg-gray-100'}
      onMouseMove={onMove}
      onMouseEnter={() => hoverZoom && setHover(true)}
      onMouseLeave={() => hoverZoom && setHover(false)}
    >
      <SmartImage
        kind="product"
        photoId={photoId}
        src={src}
        preset="pdpMain"
        alt={alt}
        aspectRatio="3/4"
        priority={priority}
        imgClassName="object-cover will-change-transform"
        imgStyle={imgStyle}
        // ✅ truyền blur xuống SmartImage
        placeholder={blur ? 'blur' : 'empty'}
        blurDataURL={blur}
      />
    </div>
  );
}
