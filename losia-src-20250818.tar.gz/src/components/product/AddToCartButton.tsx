'use client';

import { useState } from 'react';
import Link from 'next/link';

type Props = {
  productId: string;
  disabled?: boolean;
  /** Callback chạy sau khi thêm vào giỏ THÀNH CÔNG (ví dụ: track GA4) */
  onAdded?: () => void;
};

export default function AddToCartButton({ productId, disabled, onAdded }: Props) {
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);

  if (disabled) {
    return (
      <button
        disabled
        className="inline-flex items-center justify-center rounded-lg px-4 py-2 bg-gray-200 text-gray-500 cursor-not-allowed"
        aria-disabled="true"
        title="Sản phẩm đã bán"
      >
        Đã bán
      </button>
    );
  }

  const onAdd = async () => {
    if (adding) return;
    setAdding(true);
    try {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // Giữ nguyên payload theo API hiện dùng của anh (qty thay vì quantity)
        body: JSON.stringify({ productId: String(productId), qty: 1 }),
      });

      if (res.ok) {
        setAdded(true);
        // ✨ gọi callback sau khi thêm thành công (để track GA4, v.v.)
        onAdded?.();
      } else {
        // (tuỳ chọn) anh có thể thay thành toast error
        console.error('Add to cart failed', await res.text());
      }
    } catch (e) {
      console.error('Add to cart error', e);
    } finally {
      setAdding(false);
    }
  };

  if (added) {
    return (
      <div className="flex gap-2">
        <Link href="/cart" className="inline-flex items-center justify-center rounded-lg px-4 py-2 bg-black text-white">
          View cart
        </Link>
        <Link href="/checkout" className="inline-flex items-center justify-center rounded-lg px-4 py-2 bg-emerald-600 text-white">
          Checkout
        </Link>
      </div>
    );
  }

  return (
    <button
      onClick={onAdd}
      disabled={adding}
      className="inline-flex items-center justify-center rounded-lg px-4 py-2 bg-black text-white disabled:opacity-60"
    >
      {adding ? 'Adding…' : 'Add to cart'}
    </button>
  );
}
